//#define DEBUG 1
//#define DEBUGMAX 2
//#define TIMING 1


#define HP_UX 1
#define SUN_OS 2
#define LINUX 3
#define NT4_2000 4

//#define SYSTEM HP_UX
//#define SYSTEM SUN_OS
#define SYSTEM LINUX
//#define SYSTEM NT4_2000

#define FILELOG 11
#define EVENTLOG 22

//#define TYPE FILELOG
//#define TYPE EVENTLOG

#define LLEGIR 0
#define GUARDAR 1
#define PREFIX "pos_"

#define MAXPATHCHARS 1024
#define MAXFILELINE 1024
#define MAXSUBPATRONS 50

#define AND 100
#define OR 200
#define SIMPLE 300

